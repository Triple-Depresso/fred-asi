# Fred Wang oct. 9th
# did this during a holiday vacation so a lot of stuff is lazy writing, excuse the spelling and grammar
# bear with my bear-like coding
# reused some textures from last year's projects cus didnt have time to draw new stuff again

"""
This is a game that requires graphics.py
here is a install reference document: http://www.pas.rochester.edu/~rsarkis/csc161/python/pip-graphics.html

let me know if this is too much work for you to install then mark, ill send you another text based game(more simplistic)
that utilizes classes, you can reach me at freddid225@gmail.com

but i've included graphics.py in the same folder so it should load from that

-----------------------------------------------------------
this game also utilizes winsound, this is just used to have gun sound effects
-----------------------------------------------------------

allows the player to use W and S to move up and down across 4 lanes
the player would be able to have a sniper rifle that fires in a lane depending on which lane the player is in
monsters, aka. zombies will spawn in any of the 4 lanes

the objective is to kill the zombies by matching the the lanes

ex. zombie spawned in the top lane, then the player has to move to the top lane and fire the sniper rifle
this will in turn kill the zombie *and grant the player money for level ups*(not sure if im going to add)
"""

# making sure people have graphics.py installed
try:
    from graphics import *
except ImportError:
    print("Please install graphics.py")
    exit()

# needed modules
import time, winsound, random

# Small intro/tutor for the game
print("Currently the money system is not working, it will come with an update later")
print("for now you are able to buy however much ammo you'd like\r")
print("")
print("press W and S to move up and down")
print("press Space to fire")
print("press R to reload")
print("press E for ammo shop")

# - Window -
win = GraphWin("game", 1280, 720)
# graphics window, (name, width, height)

# -[ Basic world generation/set-ups ]-
# -full screen location-
fs720 = Point(win.getWidth() / 2, win.getHeight() / 2)
# full screen 720p, when ever an rendering object (like image or shape) needs to be displayed in graphics.py,
# it need a location, which is represented by the class Point(),
# Point() defines a center location for the rendering object

# -background gun range-
bg_range = Image(fs720, "Resource/Gun_Range.png")
bg_range.draw(win)
# example of how an Image object is created, utilizing the fullscreen variable and a file path
# in graphics an object needs to be created first then it is able to be rendered

# -ammo shop-
ui_shop = Image(fs720, "Resource/UI/Ammo_Shop.png")

# -lane occupancy-
lane_occ = {1:False, 2:False, 3:False, 4:False}
# keeps track of what lanes are currently being used/occupied


# -[ tools ]-
def lanes(type, num, special):
    """
    (str, int, bool) --> Point()

    returns a location (xy co-ords) for the monsters or the players to spawn at/move in

    graphics.py uses a class called Point() which gives an xy co-ord for other objects to move to/render to

    this function basically defines the xy coord for the 4 lanes, when ever a monster or player need a location of a
    lane, this function is called to get the xy coord
    """
    if 1 <= num <= 4:
        if type == "chr":
            if special:
                # read the next section for better explanation
                # this section is for the idle frame of the character, it requires a different xy co-ord
                chr_lane1 = Point(430, 95)
                chr_lane2 = Point(430, 275)
                chr_lane3 = Point(430, 455)
                chr_lane4 = Point(430, 635)

                return eval("chr_lane{}".format(num))
                # eval() is explained below

            else:
                # this defines a location for the players to move
                chr_lane1 = Point(960, 95)
                chr_lane2 = Point(430, 275)
                chr_lane3 = Point(430, 455)
                chr_lane4 = Point(430, 635)

                # eval() takes a string and see if there's any variables that's made of the same characters as the string
                # >>> x = "save me"
                # >>> eval("x")
                # "save me"
                # the adv. of eval() is that you can format a string, therefore you can change the variable in question
                # with another variable
                return eval("chr_lane{}".format(num))
                # this could have been done with 4 if statements but i was too lazy
                # if num == 1:
                #     return chr_lane1
                # also using eval allows more than 4 monsters to be added without additional code for outputting (return)
                # ask me/lmk if this is too confusing

        elif type == "mob":
            # same thing but for the monsters, aka. different xy co-ords
            mob_lane1 = Point(150, 95)
            mob_lane2 = Point(150, 275)
            mob_lane3 = Point(150, 455)
            mob_lane4 = Point(280, 635)

            # eval() explained above
            return eval("mob_lane{}".format(num))

def hit_box(ul, lr, click):
    """
    (upper left, lower right, click location)
    (Point, Point, Point) --> bool

    see if a mouse click is within a rectangular box
    done by checking the xy co-ord of both the box and the click

        X   <   .   <   X
    Y   _________________
        |               |
    <   |               |
        |               |
    .   |       .       |
        |               |
    <   |               |
        |               |
    Y   |_______________|

    im not sure if the text image works on your IDE so im sorry if this looks like a giant mess
    """
    if ul.getX() < click.getX() < lr.getX() and ul.getY() < click.getY() < lr.getY():
        return True


# -[ Monsters ]-
class Monster:
    def __init__(self, uuid):
        """
        (int)

        uuid = universal unique id, used to give an id number for the mob
        uuid has to be with in 1 - 4
        """
        if 1 <= uuid <= 4:
            self.uuid = uuid
        else:
            self.uuid = 4

        # load in the mob, the lane location is based on uuid, the picture taken is based on uuid
        self.idle = Image(lanes("mob", uuid, False), "Resource/Monsters/Zombie{}.png".format(uuid))
        self.dying = Image(lanes("mob", uuid, False), "Resource/Monster_Death/Zombie{}.png".format(uuid))

    def spawn(self):
        """
        spawns in the monster, aka. renders it on screen
        """
        self.idle.draw(win)
        lane_occ[self.uuid] = True

    def death(self):
        """
        Death animation
        """
        self.idle.undraw()
        self.dying.draw(win)
        time.sleep(0.7)
        self.dying.undraw()

        lane_occ[self.uuid] = False
        # removes the zombie from the list, aka. no longer on screen


# -[ Guns ]-
ammo_count = 5
# amount of bullets left in the chamber
clip_count = 0
# amount of clips left in inventory

# -ammo ui-
ui_ammo = Image(Point(130, 660), "Resource/UI/UI_Ammo.png")
ui_ammo.draw(win)

# ammo count ui
ui_ammo_count = Text(Point(100, 640), ammo_count)
ui_ammo_count.draw(win)

# clip count
ui_clip_count = Text(Point(100, 677), clip_count)
ui_clip_count.draw(win)


def fire_animation():
    """
    animation and sound for when the gun fires
    """
    chr_idle.undraw()
    winsound.PlaySound("Resource/Gun_Shots/AWM_SFX.wav", winsound.SND_ASYNC)
    chr_fire.draw(win)
    time.sleep(0.4)
    chr_fire.undraw()
    chr_idle.draw(win)


def reload_SFX():
    """
    Sound effects for reloading
    """
    winsound.PlaySound("Resource/Gun_Shots/AWM_Reload_SFX.wav", winsound.SND_ASYNC)


# -[ UI ]-
def menu():
    """
    options for when you press 'escape' and open the menu
    """
    main_menu = Image(fs720, "Resource/Menu/Pause.png")
    main_menu.draw(win)
    # renders the menu

    while 1:
        click = win.getMouse()
        # getMouse() returns a Point(), aka. xy co-ords of the click

        if hit_box(Point(518.0, 229.0), Point(764.0, 283.0), click):
            # option: resume
            main_menu.undraw()
            break

        elif hit_box(Point(518.0, 301.0), Point(764.0, 357.0), click):
            # option: settings
            # sorry not functional dont have time :P
            x = "Place holder"

        elif hit_box(Point(517.0, 372.0), Point(764.0, 431.0), click):
            # option: credits
            credit_screen = Image(fs720, "Resource/Menu/Credits.png")
            credit_screen.draw(win)
            while 1:
                x = win.getMouse()
                if hit_box(Point(516.0, 532.0), Point(765.0, 587.0), x):
                    credit_screen.undraw()
                    break

        elif hit_box(Point(517.0, 447.0), Point(764.0, 502.0), click):
            # option: quit
            exit()


# -instances of zombies
zom1 = Monster(1)
zom2 = Monster(2)
zom3 = Monster(3)
zom4 = Monster(4)

# -character location lane number-
chr_location = 1

# -load in the 3 frames of animation for firing the rifle-
chr_idle = Image(lanes("chr", chr_location, True), "Resource/AWM_1.png")
chr_fire = Image(lanes("chr", chr_location, False), "Resource/AWM_2.png")
chr_reload = Image(lanes("chr", chr_location, False), "Resource/AWM_3.png")

# renders the character
chr_idle.draw(win)

# starts a timer for the zombies to spawn
timer = time.time()
# and finally, the game starts hahahaahaha thisisfine
while 1:
    key = win.getKey().lower()
    # .getKey() asks for a keyboard input in the window and returns it as a string
    # .lower() makes everything lower case and easier for if statements

    if key == "w":
        # move up
        if 1 < chr_location <= 4:
            chr_location -= 1
            # moves the character location up
            chr_idle.move(0, -180)
            # moves the visual character up
            chr_fire.move(0, -180)
            chr_reload.move(0, -180)
            # moves the animation frames up


    elif key == "s":
        # move down
        if 4 > chr_location >= 1:
            chr_location += 1
            # moves the character location down
            chr_idle.move(0, 180)
            # moves the visual character down
            chr_fire.move(0, 180)
            chr_reload.move(0, 180)
            # moves the animation frames down


    elif key == "space":
        # fire
        if ammo_count > 0:
            fire_animation()
            if lane_occ[chr_location] == True:
                eval("zom{}".format(chr_location)).death()
                # eval() used here again cus if statements are too lengthy
                # if chr_location == 1:
                #     zom1.death()
                # you'll have to repeat this 4 times if eval() is not used
                # with eval() you can just .format() the zom"1" with a variable

            # delay
            time.sleep(1.1)

            # -subtracts 1 from current ammo count and update it to the display-
            ui_ammo_count.undraw()
            ammo_count -= 1
            ui_ammo_count = Text(Point(100, 640), ammo_count)
            ui_ammo_count.draw(win)


    elif key == "r":
        if clip_count >= 1:
            # makes sure there are enough clips for reloading

            # reload
            # -plays sound effects-
            reload_SFX()

            # -reload animation-
            chr_idle.undraw()
            chr_reload.draw(win)

            # -changes current bullet in chamber to 0-
            ui_ammo_count.undraw()
            ammo_count = 0
            ui_ammo_count = Text(Point(100, 640), ammo_count)
            ui_ammo_count.draw(win)

            # delay
            time.sleep(2)

            # -subtracts 1 from number of clips and display/update it
            ui_clip_count.undraw()
            clip_count -= 1
            ui_clip_count = Text(Point(100, 677), clip_count)
            ui_clip_count.draw(win)

            # delay
            time.sleep(0.6)

            # changes the current ammo count back to full (5)
            ui_ammo_count.undraw()
            ammo_count = 5
            ui_ammo_count = Text(Point(100, 640), ammo_count)
            ui_ammo_count.draw(win)

            # reload animation complete
            chr_reload.undraw()
            chr_idle.draw(win)


    elif key == "e":
        # ammo shop
        ui_shop.draw(win)
        # renders the shop ui
        while 1:
            click = win.getMouse()

            if hit_box(Point(1111.0, 590.0), Point(1263.0, 657.0), click):
                # buy 2 clip
                clip_count += 2

            elif hit_box(Point(35.0, 31.0), Point(173.0, 125.0), click):
                # exits the shop
                ui_shop.undraw()
                break

        # -updates visual UI clip amount-
        ui_clip_count.undraw()
        ui_clip_count = Text(Point(100, 677), clip_count)
        ui_clip_count.draw(win)


    elif key == "escape":
        # brings up a pause menu
        menu()

    # timer spawning monsters
    if time.time() - timer > 5:
        # if it has been more than 5 sec without spawning a mob, it spawns a mob in a random lane
        random_mob_id = random.randint(1, 4)
        # selects a random monster
        if lane_occ[random_mob_id] == False:
            # checks if the monster that wants to spawn is already spawned
            eval("zom{}".format(random_mob_id)).spawn()
            # do i really need to explain eval() again? please dont make me
            timer = time.time()
            # resets the timer
