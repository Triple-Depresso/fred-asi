import random as r
import time

print('this program is used to test your reaction time\nthe time will be displayed in ms')
print('hit enter when you see "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"')
input('hit enter to start')

while 1:
	time.sleep(r.randint(1, 4))
	print('XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX', end='')
	old = time.time()
	input()
	print(round(time.time() - old, 3) * 1000, ' ms')
