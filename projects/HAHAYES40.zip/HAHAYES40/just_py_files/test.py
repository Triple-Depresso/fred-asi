# Fred Wang Nov 18 2018
# this is a separate script for testing if the program functions properly
# this tests the writing and reading files part of the function
# this DOES NOT test username and logins function

if __name__ == "__main__":
    # will only run the script if this (test.py) is not being imported as a module

    print("-Testing Script-")

    import main, threading, en_de, time, os

    key = "0xA13"

    def main1():
        # creates the file
        msg = en_de.encode(["Hello World", "This is Fred", "End of third line", "End of testing script"], key)
        main.file_creation(msg, "testfile")
        main.leave()
        print(1)

    def main2():
        # reads the file
        print(2)
        return main.file_read("testfile", key)



    # the creation process will cause program to exit
    # using a thread the main script does not exit, rather the thread will exit
    # think of it like running 2 scripts and only one of them will exit
    x = threading.Thread(target=main1)
    x.start()

    while 1:
        # waiting for the file to be created before reading it
        time.sleep(0.3)
        try:
            f = open("testfile.txt", 'r')
            f.close()
            break
        except FileNotFoundError:
            continue

    if main2() == ["Hello World", "This is Fred", "End of third line", "End of testing script"]:
        print("\ntest successful")

    else:
        print("\ntest unsuccessful - encryption error")
    # reads the file and compares it to the original

    print("\nend of test")

    os.remove("testfile.txt")
    # cleans up the file
