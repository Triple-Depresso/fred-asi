# Fred Wang Oct. 23 2018
"""
en_de - encode_decode/encrypt_decrypt

takes a list of words and encrypts or decrypts it

this is done by taking the ord() of each character and shifting it according to the key
the key is a hex that translate into a number

--how encoding and decoding works--
chr() translates a number into a character
ord() translates a character into a number
the key is a number that came from a hex

the ord() of each character is taken and the key was added
then it is translated back into a character

- new character = ord(old_character) + key

decoding works the opposite way
it takes the encoded character, find the ord of that character,
subtracts the key from it, then turns it back into a character

- decoded = ord(encoded) - key

"""

def encode(msg, key):
    """
    (list, hex) --> list

    takes a list of words and encode it using the key

    >>> encode(["hello", "world"], "0x123")
    ['ƋƈƏƏƒ', 'ƚƒƕƏƇ']
    """

    int_key = int(key, 16)

    # encrypt
    after_en = []
    for word in range(len(msg)):
        temp_word = ""
        for count in msg[word]:
            temp_word += chr(ord(count) + int_key)
        after_en.append(temp_word)

    return after_en


def decode(msg, key):
    """
    (list, hex) --> list

    takes a list of words and decode it using the key

    >>> decode(['ƋƈƏƏƒ', 'ƚƒƕƏƇ'], "0x123")
    ["hello", "world"]
    """

    # getting an int from hex
    try:
        # incase people do not enter a hex for the key
        int_key = int(key, 16)
    except ValueError:
        print("this is not a valid key!")
        return

    # decrypt
    after_de = []
    for word in range(len(msg)):
        temp_word = ""
        for count in msg[word]:
            if int_key < ord(count):
                # if people tries to enter a large number
                temp_word += chr(ord(count) - int_key)
            else:
                print("INVALID KEY GO AWAY")
                return "GO AWAY"
                # stops the process with error code: GO AWAY
        after_de.append(temp_word)

    return after_de
