# Fred Wang Oct. 23 2018
# this is my first utilizing/creating my own python module so the code is spaghetti
"""
tldr uses for 2 extra .py files;
-create new accounts, saves/writes to logins.py to create new instances, it has a User class
-logins, imports logins.py and uses instances in the file
-en_de, encode and decode, organizing encoding and decoding tools to a different file
 can be called using en_de.function_name()

Scenario

You're trying to have a private chat online with your friend in the other class, but you don't want your teacher,
or anyone else who may be looking at your screen, to happen upon a message at an inopportune moment.
So you decide to write a function to encrypt your messages so that they're not immediately legible
if someone were to glance at your screen

You can make the encryption as complex as you like, keeping in mind that your friend will need to be able to decrypt it
in order to read it. Your program should be able to read a message from an encrypted file and decrypt it given a key.
It should also give the user the option to enter plain text and write the encrypted message to a file.

upgrades -
online messaging systems usually send data in 'packets', this will be represented using .txt files with the name
'sender_incoming.txt'
the program will read and decrypt the encrypted msg and print(on the console) out the decrypted msg
the user will also be able to send msg and it will be a encrypted output as the file name 'sende_outgoing.txt'

the user will also need to login with the correct username and password
once a user has been created, the system will automatically generate a key

i encrypt with my key
i decrypt with sender's key

the sender will have to give the receiver the key through a different medium

- not sure if im going to add -
the user can also friend someone so that their msg will always be auto decrypted
aka. you dont need to input the sender's key every time
"""

import os, random, time, logins, en_de
# os - deleting files

log = open("logins.py", "a")

class LogInGlobal:
    """
    this is in place of a global variable
    used classes cus global variables are too unreliable

    background info:
    a class attribute acts like a global variable, its is the same in and out of a function
    """

    def __init__(self):
        # used to keep track of if a user is currently logged on or not
        self.logon = False
        self.uname = None

mainlog = LogInGlobal()

def create_acc():
    """
    creates a new user
    this is done by editing the code in 'logins.py'
    """
    while 1:
        print("Please enter your desired username and password, or enter nothing to cancel")
        u_input = input("uname: ")
        p_input = input("pword: ")

        if u_input == "":
            return
            # used in case people dont input anything

        # - making sure usernames contains letters -
        try:
            u_input.lower()
        except AttributeError:
            print('Username must contain letters')


        try:
            """
            used to detect if the username already exists
            works by taking the new uname and seeing if there's any existing variable that matches it
            try and except used instead of if statement because:
            if statements requires the log file to be opened in 'r' instead of 'a'
            
            using try and except i can just test if a variable exists by TRYING to use that variable
            
            example.
            x = y
            NameError: name 'y' is not defined            
            
            now I know y is not a variable (not in the data base)
            """
            temp = eval("logins.{}.u".format(u_input))
            print("the username:", u_input, "already exists, please enter another username")
            continue

        except AttributeError:
            # if the username does not already exist
            print("your username is:", u_input, "and password is:", p_input)

            conf_gate = input("hit enter to continue, 'stop' to cancel or anything to edit").lower()
            # conf_gate = Confirm gate, used to make sure if the uname and pword are as the user desires
            # .lower() is used if catch if anyone tries to input a valid option with caps

            if conf_gate == "":
                key = hex(random.randint(0, 1000))
                # generates a key, formatted as a hex (im too lazy to make my own key encryption)

                log.write("\n{} = User('{}', '{}', '{}')\n".format(u_input, u_input, p_input, key))
                # adds a new user
                # formatted as declaring a new variable in logins.py
                # tldr; making my code write its own code
                # code A writes code B, restart code A, Code A will now use code B

                print("The program needs to restart to register the information, the program will now exit")
                exit()
                # reimport the data base so the new account will be registered

            elif conf_gate == "stop":
                return
                # return used to exit the account creation process


def login():
    """
    sets the class attribute - mainlog.logon to true
    basically letting the system know that a user is currently logged on
    also keeps track of who is logged on
    """
    while 1:
        print("\nInput your username and password, enter nothing to cancel")
        u_input = input("uname: ")
        p_input = input("pword: ")

        if u_input == "":
            return
            # used in case people dont input anything

        try:
            # i explained this already
            # this time it's just the other way around
            # this catches invalid account names
            temp = eval("logins.{}.u".format(u_input))
            pass

        except AttributeError:
            print("This is not a valid username, Please try again")
            continue

        if u_input == eval("logins.{}.u".format(u_input)) and p_input == eval("logins.{}.p".format(u_input)):
            """ 
            helpme
            eval() takes a string and see if there's any variables that's made of the same characters as the string
            >>> x = "save me"
            >>> eval("x")
            "save me"
            the adv. of eval() is that you can format a string, therefore you can change the variable in question
            with another variable
            
            logins refers back to the imported file
            .{}.format refers back to the User instance name within the file
            .u refers back to the class attribute
            the instance name should be the same as the .u attribute (.{}.format = .u)
            
            in short - logins > class > class attribute
            if statement looks for a specific instance's attribute within the logins file and see 
            if the username is the same as inputted
            """
            print("--[Logged on]--")
            mainlog.logon = True
            # logged on
            mainlog.uname = u_input
            # who logged on
            return

        else:
            print("Incorrect Username or Password")

def msg_input():
    """
    returns a list
    each item is a line within the msg
    """
    list_words = []

    print("\nPlease begin to type your message, enter /exit on a new single line to stop")
    print(" ---------------------------- ")
    while 1:
        # takes in multiple lines of msg
        line = input()

        if line == "/exit":
            break
        else:
            list_words.append(line)

    return list_words


def file_creation(en_msg, file_name):
    """
    (list, str) --> new file

    file_creation
    creates a file with given a msg
    each item in the list would represent a line in the file

    uses the argument, encoding="utf-8", this is required as the ord() shift contains
    characters open() cant read normally
    source: https://stackoverflow.com/questions/27092833/unicodeencodeerror-charmap-codec-cant-encode-characters
    """

    send = open("{}.txt".format(file_name), 'w', encoding="utf-8")
    # new file

    for lines in range(len(en_msg)):
        # writes each item in the list to the file as a new line
        send.write(en_msg[lines])
        send.write("\n")

    send.close()

    print("you will need to restart the system for the output file to appear")

def file_read(file_name, key):
    """
    (str) --> print()

    reads an encrypted file and prints it on the console
    
    encoding="utf-8" explained above
    """
    try:
        # opens the file using the file name
        f = open("{}.txt".format(file_name), 'r', encoding="utf-8")
    except FileNotFoundError:
        # displays error and file name
        print("Error 303 - {}.txt not Found".format(file_name))
        return

    print('File successfully loaded!')

    raw_list = f.readlines()

    # - raw list has a '\n' at the end of every str/item, '\n' gets removed here -
    new_list = []
    for item in raw_list:
        new_list.append(item.replace("\n", ""))
        # removes \n

    # decodes the list using the method .decode in the en_de module
    decoded_list = en_de.decode(new_list, key)

    # stop the process when received the error code
    if decoded_list == "GO AWAY":
        return

    # prints out the msg
    print("Here is the message decrypted using the key provided({})\n".format(key))
    for lines in decoded_list:
        print(lines)

    return decoded_list

def send_help():
    """
    displays the available options
    different options for when someone is logged on
    """
    if mainlog.logon == False:
        print(" ----------------------------- ")
        print("These are the available options")
        print("login -- log into your account")
        print("create - create an account")
        print("read --- read messages from others")
        print("help --- displays this help screen")
        print("exit --- exits the program")

    elif mainlog.logon == True:
        print(" ----------------------------- ")
        print("These are the available options")
        print("write -- write your msg")
        print("read --- read messages from others")
        print("key ---- displays the key you encode your messages with")
        print("logout - logs out of your account")
        print("help --- displays this help screen")
        print("exit --- exits the program")

def leave():
    # exits the program
    exit()

if __name__ == "__main__":
    # runs this script (aka. ask for options) if THIS (the main.py) file is the one being ran
    # in other words, will only run the script if this (main.py) is not being imported as a module
    while 1:
        option = input("\nPlease input an action or 'help': ").lower()

        if mainlog.logon == False:
            # when there are no accounts logged on
            if option == "login":
                login()

            elif option == "create":
                create_acc()

            elif option == "read":
                file_name = input("please input the file name excluding the .txt: ")
                key = input("Please enter the key: ")
                decoded_list = file_read(file_name, key)

                while 1:
                    # asks if the user wants an output on the decoded msg
                    print_choice = input("would you like to save this as a file? (y/n): ").lower()

                    if print_choice == "y" or print_choice == "yes":
                        # creates the file
                        name = input("What would you like your file name to be? ")
                        input("Please note that all files with the name {}.txt will be replaced, press enter to continue".format(name))
                        file_creation(decoded_list, name)
                        break

                    elif print_choice == "n" or print_choice == "no":
                        # exits process
                        break

                    else:
                        print("not a valid option")

            elif option == "help":
                send_help()

            elif option == "exit":
                exit()

        if mainlog.logon == True:
            # when there is an account logged on

            if option == "write":
                input("*any pre-existing messages will be removed, please save your messages and then press enter to continue")
                # warns the user to save the msg before continuing
                file_name = input("What would you like your file name to be? ")
                file_creation(en_de.encode(msg_input(), eval("logins.{}.key".format(mainlog.uname))), file_name)
                """ 
                eval(...)              > gets the user's key
                msg_input()            > gets the user's msg
                en_de.encode()         > encodes the user's msg using the key
                file_creation()        > creates the file with the encoded user msg and the file name
                """

            elif option == "read":
                # read from a file
                file_name = input("please input the file name excluding the .txt: ")
                key = input("Please enter the key: ")
                decoded_list = file_read(file_name, key)

                while 1:
                    # asks if the user wants an output on the decoded msg
                    print_choice = input("would you like to save this as a file? (y/n): ").lower()

                    if print_choice == "y" or print_choice == "yes":
                        # creates the file
                        name = input("What would you like your file name to be? ")
                        input("Please note that all files with the name {}.txt will be replaced, press enter to continue".format(name))
                        file_creation(decoded_list, name)
                        break

                    elif print_choice == "n" or print_choice == "no":
                        # exits process
                        break

                    else:
                        print("not a valid option")

            elif option == "key":
                # displays the user's key
                print("This is your key:", eval("logins.{}.key".format(mainlog.uname)))

            elif option == "logout":
                # logout
                mainlog.logon = False
                mainlog.uname = None
                print("--[Logged out]--")

            elif option == "help":
                # displays help
                send_help()

            elif option == "exit":
                exit()