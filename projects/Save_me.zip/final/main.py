# Fred Wang
# Dec. 17 2018
"""
Algorithm Analysis
Create a Python program to determine the time it takes in milliseconds to sort a list of integers in ascending order
using a selection sort.

The list of integers should be randomly generated.
The length of the list, n, should be specified by the user and the sort time displayed.

The user should also have the option to generate several lists of various default lengths
(e.g. 1000, 2000, 4000, 8000, 16000, 32000, 64000). The sort times for each list should be written to an external file.


*note*
The final project ended up being really boring and not that code based
(a lot of work in the engine, not much in the writing code part)

so i ended up spending a lot of time in this program, including excessive uses of classes
tbh im not sure what functions that i created was actually used later

this program is way too over complicated for what the requirements are, feel free to just see if it runs properly
and skip over reading the code, im not sure even i would understand if i tried to read this now
(assuming i would ever even bother to look at this again)

 - to ignore all the UI stuff -
so there's a bunch of code that does not affect the sorting, timing, and output of th results
these are user friendly options
to ignore these, a bit complicated to mark
look at sample_test()



i tried to include as many helpful comments as possible, however the comments only explain small section of the code,
it does not explain how everything fits together

-variables that will be used/referenced-
read sendhelp() for a better explanation

max_num/cap
    the highest number the numbers in the list can be

len/length
    number of items/numbers in the list

num_test
    how many tests are ran, aka. how many times are we timing and sorting a list

saves/simulations
    sets of data that contains how long it takes to sort different lengths of lists
"""

import time, random
import threading as t

print('note: the speed/result of this test will vary from computer to computer')


def get_int(msg):
    """
    (str)
    get_len -> int

    get the length of the list from the user
    """
    while 1:
        try:
            return int(input(msg))
        except ValueError:
            print('please input a number')
            continue


def get_max():
    """
    function specifically made to get the max int possible
    """
    while 1:
        try:
            return abs(int(input('please input the max integer possible for the num in the lists\n'
                                 'this will be the standard across all tests: ')))

        except ValueError:
            print('please input a number')
            continue


class Fred:
    """
    A basic list
    contains functions that sorts the list
    """
    def __init__(self, length, max_num):
        """
        (int, int)
        """
        self.len = length
        self.cap = max_num

        self.active_thread = False
        # if the list is currently being sorted in the background by a thread
        self.time = None
        # variable for time it takes to sort, only has a value AFTER self.timed_sort() has been used

        # - generate a list with randomized numbers -
        temp_list = []
        for x in range(0, self.len):
            temp_list.append(random.randint(0, self.cap))
        self.raw = temp_list

    def base_sort(self):
        """
        base_sort() -> list
        raw_list -> sorted_list

        slow method of sorting
        checks/find lowest number possible and appends the lowest possible number to a new list
        """
        x = []
        for count in range(0, self.cap):
            for data in self.raw:
                if data == count:
                    x.append(data)
        return x

    def timed_sort(self):
        """
        timed_sort -> int
        raw_list -> time_it_took_to_sort

        base sort but it returns a int representing time(ms) it took to sort
        also adds the amount of items and time to the history
        """
        old = time.time()
        x = []
        for count in range(0, self.cap):
            for data in self.raw:
                if data == count:
                    x.append(data)
        total = round(time.time() - old, 3)*1000

        self.time = total
        return total

    def thread_base_sort(self):
        """
        base function used for thread_sort
        cannot use base_sort() as it does not turn on self.active_thread
        """
        self.active_thread = True

        # sort
        x = []
        for count in range(0, self.cap):
            for data in self.raw:
                if data == count:
                    x.append(data)

        self.active_thread = False

        return x

    def thread_sort(self):
        """
        thread_sort -> list
        raw_list -> sorted_list

        base sort but in the background allowing you to do different tasks
        """
        sT = t.Thread(target=self.thread_base_sort)
        sT.daemon = True
        sT.start()


class History:
    """
    tldr; a better list made specifically for this program

    functions:
        python
        stores lists in dictionaries, dictionary keys are used to call the data sets

        plain
        you have save slots
        you can create more save slots
        each save slot can save multiple data sets
        a data set contains: 1 amount of items, 1 time

        think of it like a game save, and in the game(that save) you have a chest with items
    """
    def __init__(self):
        """
        example of main
        {1:[(amount, time), (amount, time)], 2:[(amount, time), (amount, time)]}
        {  save:[ (data, data) ]  }
        """
        self.main = {}
        self.save_slot = 1
        self.main[1] = []

    def new(self, slot):
        """
        (int)
        create a new slot and set the selection to the new slot
        """
        self.save_slot = slot
        self.main[self.save_slot] = []

    def set(self, save_slot):
        """
        (int)
        select a save slot
        """
        self.save_slot = save_slot

    def add(self, amount, timed):
        """
        (int, int)
        add data to the selected slot
        """
        self.main[self.save_slot].append((amount, timed))

    def load(self, slot):
        """
        (int)
        loads a specific save slot WITHOUT affecting the current selected slot
        """
        return self.main[slot]


class Multi:
    def __init__(self, max_num):
        """
        (int)
        """
        self.cap = max_num
        self.history = History()
        self.test_count = 0

    def semi_auto(self, starting_amount, num_test):
        """
        (int, int)

        user inputs a starting number and the type of sorting(base sort or thread sort),
        the starting number is the length of the list and
        the length of the list goes up by a multiple of 2 for every test

        ex. input -> 2000 items, 5 tests
        1. 2000 items
        2. 4000 items
        3. 8000 items
        4. 10000 items
        5. 20000 items
        """
        self.test_count += 1
        self.history.new(self.test_count)

        for counter in range(0, num_test):
            temp_list = Fred(starting_amount, self.cap)
            timed = temp_list.timed_sort()
            print("list {} containing {} items sorted".format(counter + 1, starting_amount))
            # getting the time it takes to sort

            self.history.add(starting_amount, timed)
            # add record to history

            starting_amount *= 2
            # doubles the amount of items

    def manual(self, num_test):
        """
        (int)

        The user will have to input each specific number of items in the test,
        the amount of tests is predetermined by other inputs
        """
        self.test_count += 1
        self.history.new(self.test_count)
        temp_amount_list = []

        check = input("by hitting enter, you will be asked {} times to input the amount of items you want for each test\n"
                      "enter 'stop' to cancel".format(num_test)).lower()
        if check == 'stop':
            return

        # -getting the amounts and storing it-
        for helpme in range(0, num_test):
            amount = get_int("input the amount of items you want for this test\ntest ({}): ".format(helpme + 1))
            temp_amount_list.append(amount)

        # sorting it
        temp_sort_count = 0
        for amount in temp_amount_list:
            # create and time the list
            temp_sort_count += 1
            temp_list = Fred(amount, self.cap)
            timed = temp_list.timed_sort()

            print("list {} containing {} items sorted".format(temp_sort_count, amount))
            # indicate that a list is sorted

            self.history.add(amount, timed)
            # add record to history

    def output(self, file_name):
        """
        (str)

        outputs the time and amount of item
        """
        f = open(file_name, 'w')

        # loads the data
        # self.history.main -> dictionary
        for save in self.history.main:
            f.writelines(["Simulation ({})\n\n".format(save)])
            # get the list
            for data in self.history.main[save]:
                # get the tuple
                amount = data[0]
                timed = data[1]
                # load stuff from tuple
                f.writelines(['Items: {}\n'.format(amount), 'Time: {}ms\n\n'.format(timed)])

            f.write("\n\n")


def sample_test():
    """
    contains the basic functions that this program provides

    auto create list and sort it, output is sample.txt
    """

    max_num = 999
    num_test = 5

    test = Multi(max_num)

    # simulation 1
    test.semi_auto(1000, num_test)

    # simulation 2
    test.semi_auto(500, num_test)

    # simulation 3
    test.manual(num_test)

    # output
    test.output("sample.txt")


def sendhelp(type):
    """
    (int)

    function to display the options available for the user
    also displays how certain aspects of the system works

    type defines what kinda of help the users need in certain situations
    """
    if type == 2:
        # how it works
        print("""
        numbers -> lists -> sort time -> tests -> saves
        this program generates lists with random numbers in it
        each test (creating, sorting, and timing it) will be referred to as a 'test'
        
        the following data are stored
            - the highest number the numbers in the lists can be (max)
            - amount of items in the list                        (length)
            - time it takes to sort                              (time)
            - amount of tests performed                          (tests)
            - amount of times a series of tests are ran          (saves/simulation)
        """)

    elif type == 1:
        # main menu options
        print("""
        help - displays how the system works and options available
        start - start the program
        """)

    elif type == 3:
        # sub menu options
        print("""
        help      - displays how the system works and options available
        semi-auto - semi auto creation, a starting item amount is inputted
        manual    - fully manual creation, each test's item amount is inputted
        output    - output the results
        exit      - exits the program""")

    elif type == 4:
        # how semi auto works
        print("""
        Semi-Auto (input 'semi' or 'semi auto')
        
        user inputs a starting number and the type of sorting(base sort or thread sort),
        the starting number is the length of the list and
        the length of the list goes up by a multiple of 2 for every test
        
        ex. input -> 1000 items, 5 tests
        1. 2000 items
        2. 4000 items
        3. 8000 items
        4. 16000 items
        5. 32000 items
        """)

    elif type == 5:
        # how manual works
        print("""
        Manual (input 'manual')
        
        user inputs the amount of items for each test
        
        ex. 5 tests
        1. (ask for input) items
        2. (ask for input) items
        3. (ask for input) items
        4. (ask for input) items
        5. (ask for input) items
        """)
        pass


if __name__ == "__main__":
    while 1:
        option = input("Please input an option(or help): ").lower()

        if option == "help":
            # displays the basic help menu
            sendhelp(1)
            sub_options = input('enter "1" to see how this system works, enter nothing to cancel: ').lower()

            if sub_options == "1":
                # displays how the system works
                sendhelp(2)

        elif option == "start":
            # initialize the system
            max_num = get_max()
            # counter is the amount saves/simulations
            counter = 0

            # start the main variable
            main = Multi(max_num)

            while 1:
                sub_options = input("Please input the sorting method (or help): ").lower()

                if sub_options == "help":
                    sendhelp(3)
                    sub_options = input("""
        enter "1" - how to use semi-auto
        enter "2" - how to use manual
        enter nothing to cancel: """).lower()
                    if sub_options == "1":
                        # explains semi-auto
                        sendhelp(4)

                    elif sub_options == "2":
                        # explains manual
                        sendhelp(5)

                elif sub_options == "semi" or sub_options == "semi_auto":
                    # create a new simulation
                    counter += 1
                    print("-[Simulation {}]-".format(counter))

                    # semi auto sort
                    num_test = get_int("Please indicate the amount of test you would like completed for this save: ")
                    starting = get_int("Please input the starting number: ")
                    print('sorting...')
                    main.semi_auto(starting, num_test)

                elif sub_options == "manual":
                    # create a new simulation
                    counter += 1
                    print("Save {}".format(counter))

                    # manual sort
                    num_test = get_int("Please indicate the amount of test you would like completed for this save: ")
                    main.manual(num_test)

                elif sub_options == "output":
                    # outputs the file
                    file_name = input("please input the file name including the file type(.txt)")
                    main.output(file_name)

                elif sub_options == "exit":
                    exit()
