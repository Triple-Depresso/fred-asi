# Fred Wang Oct. 23 2018
"""
this file acts like a data base for the main python file
but instead of a strait up .txt file with all the names and pwords saved there

i created a .py file with a User class
makes my life a lot easier and harder at the same time

the main.py file writes/creates new instances based on username and password inputs(in main.py)
then once an instance is created here main.py can load the instance and get the needed data such as the key

ex.
Code A makes code B, then code A uses code B

good luck reading/understanding the spaghetti code :)
"""

class User:
    """
    stores the username, password and the encoding key
    """
    def __init__(self, u, p, key):
        """
        (str, str, str)
        """
        self.u = u
        self.p = p
        self.key = key

admin = User('admin', "1080", "0x167")
